package application3;

import java.util.Scanner;

public class Application3 {

    public static void main(String[] args) {

        // This program guess a person birthdate with the givien detial.
        Scanner input = new Scanner(System.in);
        String birth = "2004 8 24";
        System.out.println("What do you guess. Remember that should be in order of yyyy m dd");
        String guess = input.nextLine();
        if (guess.equalsIgnoreCase(birth)) {
            System.out.println("Unbelevible! you found it at the very first guess");
        } else {
            while(true){
            System.out.println("Unfortunitly you didn't find that");
            System.out.println("Do you need some help yes or no?");
            String help = input.nextLine();
            if (help.equalsIgnoreCase("yes")) {
                System.out.println("In years it is from 2000 to 2005");
                System.out.println("what do you think now about my age");
                String guess2 = input.nextLine();
                if (guess2.equalsIgnoreCase(birth)) {
                    System.out.println("Well done you find that");
                    break;
                } else {
                    System.out.println("Oops! you didn't find it agian");
                    System.out.println("Do you need more help yes or no?");
                    String help2 = input.nextLine();
                    if (help2.equalsIgnoreCase("yes")) {
                        System.out.println("To help you more it is from 6 to 8 in mounth and from 20 to 25 in days");
                        System.out.println("What do think now");
                        String guess3 = input.nextLine();
                        if (guess3.equalsIgnoreCase(birth)) {
                            System.out.println("Good job you found that");
                            break;
                        } else {
                            System.out.println("Oops! the answer is incorrect, try agian ");
                        }
                    } else {
                        System.out.println("It means you want to make it by yourself");
                        System.out.println("So then tell me the correct answer");
                        String g3 = input.nextLine();
                        if (g3.equalsIgnoreCase(birth)) {
                            System.out.println("Wow you found that by YOUrself");
                            break;
                        } else {
                            System.out.println("No the answer is wrong the next time try to choose the help option");
                        }
                    }
                }
            } else {
                System.out.println("it seems that you want to find it by yourself");
                System.out.println("So now what do you think");
                String g2 = input.nextLine();
                if (g2.equalsIgnoreCase(birth)) {
                    System.out.println("Amaizing you did it by YOUrself");
                    break;
                } else {
                    System.out.println("It is wrong the next time try to choose the help option");
                }
            }
            }
        }

    }
}

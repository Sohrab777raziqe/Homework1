package bmi;

import java.util.Scanner;

public class BMI {
public static void main(String[] args) {
    Scanner weigh = new Scanner (System.in);
    System.out.println("Please input your weight in KG: ");
    double weight = weigh.nextDouble();
    System.out.println("Please input your height in meters: ");
    double height = weigh.nextDouble();
    double BMI = weight / (height * height);
    System.out.println("The body mass index (BMI) is" +BMI+"KG/m2");
    }   
}

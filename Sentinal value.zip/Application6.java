package application6;

import java.util.Scanner;
import java.util.Random;

public class Application6 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        int cont;
        while (true) {
            System.out.println("A number from 0 to 9 will termnate the game otherise enter new number");
            cont = input.nextInt();

            if (cont == 0) {
                System.out.println("The game termnated");
                break;
            } else {
                System.out.println("The game still continues try another number");
            }
        }
    }
}

package application6;

import java.util.Scanner;
import java.util.Random;

public class Application6 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Random in = new Random();
        int ran = in.nextInt(100);
        int cont = 0;
        while (3 != 2) {
            System.out.println("What do you think the number whould be?");
            int a = input.nextInt();
            cont++;
            if (a == ran) {
                System.out.println("Well done you found that at your "+cont+"th try");
                break;
            } else if (a > ran) {
                System.out.println("Your number is greater try agian");
            } else if (a < ran) {
                System.out.println("Your number is smaller try agian");
            }

        }
    }
}

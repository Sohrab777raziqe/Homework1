package adding.numbers.by.methods;

public class AddingNumbersByMethods {

    public static void main(String[] args) {
        System.out.println("the addition of numbers from 1-100 is \n" + sum(1, 100));
        System.out.println("The colection of numbers from 101- 200 is \n" + sum(101, 200));
        System.out.println("The colection of numbers from 201-300 is \n" + sum(201, 300));
    }

    public static int sum(int a, int b) {
        int c = 0;
        for (a = 1; a <= b; a++) {
            c += a;
        }
        return c;

    }

}

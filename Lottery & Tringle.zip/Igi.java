package igi;

import java.util.Random;
import java.util.Scanner;

public class Igi {

    public static void main(String[] args) {
        //This program challenges user`s luck!
        Random c = new Random();
        int a = c.nextInt(9);
        int b = c.nextInt(9);
        Scanner in = new Scanner(System.in);
        System.out.println("enter the first number from 1...9");
        int ad = in.nextInt();
        System.out.println("enter the secound number from 1...9");
        int bc = in.nextInt();

        if (a == ad && b == bc) {
            System.out.println("wonderful! you have won 10000$"+"\n\n");
        } else if (a == bc && b == ad) {
            System.out.println("congratulation you won 3000$"+"\n\n");
        } else if (a == ad || b == bc) {
            System.out.println("you got 1000$");
        } else {
            System.out.println("Oops you have lost your chance"+"\n\n");
        }

        //This programe finds a tringle`s angles by using cosine low.
        Scanner input = new Scanner(System.in);
        int x1, x2, x3, y1, y2, y3;
        System.out.println("Enter values for cordinates in order from x1,y1___ up to y3");
        x1 = input.nextInt();
        y1 = input.nextInt();
        x2 = input.nextInt();
        y2 = input.nextInt();
        x3 = input.nextInt();
        y3 = input.nextInt();
        System.out.println("x1 =" + x1 + "\t y1 =" + y1 + "\t x2 =" + x2 + "\t y2=" + y2 + "\t x3=" + x3 + "\t y3 =" + y3 + "\n");

        double cc = Math.sqrt(Math.pow((y2 - y1), 2) + Math.pow((x2 - x1), 2));
        double aa = Math.sqrt(Math.pow((y3 - y2), 2) + Math.pow((x3 - x2), 2));
        double bb = Math.sqrt(Math.pow((y3 - y1), 2) + Math.pow((x3 - x1), 2));

        System.out.println("The distnce between each cordinate is ");
        System.out.println("between(x1,y1),(x2,y2)=" + aa + "\nbetween(x2,y2),(x3,y3)=" + bb + "\nbetween(x1,y1),(x3,y3)=" + cc + "\n");

        double A = Math.acos((aa * aa - bb * bb - cc * cc) / (-2 * bb * cc));
        double B = Math.acos((aa * aa - bb * bb - cc * cc) / (-2 * aa * cc));
        double C = Math.acos((aa * aa - bb * bb - cc * cc) / (-2 * bb * aa));

        System.out.println("The valuse of each angles equals:");
        System.out.println("A =" + A + "\nB =" + B + "\nC =" + C);

    }

}

package application6;

import java.util.Scanner;
import java.util.Random;

public class Application6 {

    public static void main(String[] args) {

        while (true) {
            Random in = new Random();
            int a = in.nextInt(99);
            int b = in.nextInt(99);
            Scanner input = new Scanner(System.in);
            System.out.println("Solve the question " + a + "+" + b + "");
            int usum = input.nextInt();
            int sum = a + b;
            if (sum == usum) {
                System.out.println("well done it is corect");
                break;
            } else {
                System.out.println("The answeer is wrong try again");
            }

        }
    }

}

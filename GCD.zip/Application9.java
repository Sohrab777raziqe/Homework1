package application9;

import java.util.Scanner;

public class Application9 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Enter two numbers inorder to find there GCD");
        int a = input.nextInt();
        int b = input.nextInt();

        a = Math.abs(a);
        b = Math.abs(b);
        int max = Math.max(a, b);
        int min = Math.min(a, b);
        
        while (min != 0) {
            int re = max % min;
             max = min;
            min = re;
        }

        System.out.println("GCD is "+max);
    }

}

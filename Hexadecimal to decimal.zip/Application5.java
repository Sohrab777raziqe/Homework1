package application5;

import java.util.Scanner;

public class Application5 {

    public static void main(String[] args) {

        //This program changes Hexadecimal to decimal number.
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a value in Hexadecimal");
        String hexadecimal = input.nextLine();
        int decimal = Integer.parseInt(hexadecimal, 16);
        System.out.println("The decimal value is \n" + decimal);

        // This program converts decimal to Hexadecimal.
        System.out.println("Enter a value for decimal");
        int dec = input.nextInt();
        String hexa = Integer.toHexString(dec).toUpperCase();
        System.out.println("The Hexadecimal value is \n" + hexa);

    }

}

package application3;

import java.util.Scanner;

public class Application3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        System.out.println("Please enter an Afgan number. ");
        String num = input.next();
        if (num.length() == 10) {
            if (num.startsWith("074")) {
                System.out.println("you have dialed a Salam number.");
            } else if (num.startsWith("076") || num.startsWith("077")) {
                System.out.println("you have dialed a MTN number.");
            } else if (num.startsWith("073") || num.startsWith("078")) {
                System.out.println("you have dialed an Etisalat number.");
            } else if (num.startsWith("079") || num.startsWith("072")) {
                System.out.println("you have dialed a Roshan number.");
            } else {
                System.out.println("the nuumber you have dialed isn't available in Afganistan.");
            }
        } else if (num.length() > 10) {
            System.out.println("The number that you entered is over 10 digits.");
        } else {
            System.out.println("The number that you entered is below 10 digits.");
        }
    }
}
